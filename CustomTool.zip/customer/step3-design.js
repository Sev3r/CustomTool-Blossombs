/**
 * step3-design.js
 * Stap 3: Ontwerp uploaden of maken met Fabric.js.
 * Canvas is gekoppeld aan gekozen personalisatietype.
 * Canvas blijft binnen de beschikbare viewport.
 * Export gebeurt op basis van werkelijke afmetingen van personalisatie op 300 DPI.
 */

const DESIGN_STATE_KEY = 'cot_design_state';

let fabricCanvas = null;
let fabricHistory = [];
let fabricActiveColor = '#1D9E75';
let fabricBackgroundColor = '#b7bdb8';
let uploadedDataURL = null;
let uploadedFileName = null;
let uploadedCheck = null;
let uploadedPdfDataURL = null;
let uploadedRillinesPdfDataURL = null;
let activeDesignTab = 'tool';
let fabricInitToken = 0;
let fabricInitTimer = null;
let canvasZoom = 1;

const CANVAS_ZOOM_MIN = 0.5;
const CANVAS_ZOOM_MAX = 3;
const CANVAS_ZOOM_STEP = 0.1;

const IMAGE_DPI_RECOMMENDED = 300;
const IMAGE_DPI_MINIMUM = 150;

const CENTER_SNAP_THRESHOLD_PX = 6;
const CENTER_GUIDE_COLOR = '#5C7A5C';
const CENTER_GUIDE_STROKE_WIDTH = 1.25;
const CENTER_GUIDE_DASH = [6, 4];

const AVAILABLE_FONTS = [
  { label: 'Georgia', value: 'Georgia' },
  { label: 'Playfair Display', value: "'Playfair Display', serif" },
  { label: 'Montserrat', value: "'Montserrat', sans-serif" },
  { label: 'Lato', value: "'Lato', sans-serif" },
  { label: 'Raleway', value: "'Raleway', sans-serif" },
  { label: 'Oswald', value: "'Oswald', sans-serif" },
  { label: 'Pacifico', value: "'Pacifico', cursive" },
  { label: 'Courier Prime', value: "'Courier Prime', monospace" },
];

function renderDesignPage() {
  const el = document.getElementById('page-design');
  const product = Session.getProduct();
  const options = Session.getOptions();
  const saved = Session.getDesign() || {};

  if (!product) {
    navigateTo('select');
    return;
  }

  if (!options) {
    navigateTo('options');
    return;
  }

  const persTypes = Array.isArray(product.personalisatieTypes)
    ? product.personalisatieTypes.filter(persType => persType.active !== false)
    : [];

  const activePers = persTypes.find(persType => persType.id === options?.persTypeId) ||
    options?.persType ||
    persTypes[0] ||
    null;
  const stateKey = `${DESIGN_STATE_KEY}_${product.id}_${activePers?.id || 'standaard'}`;
  const savedState = loadDesignState(stateKey);

  uploadedDataURL = saved.dataURL || savedState?.dataURL || null;
  uploadedFileName = saved.fileName || savedState?.fileName || null;
  uploadedCheck = saved.uploadCheck || savedState?.uploadCheck || null;
  uploadedPdfDataURL = saved.pdfDataURL || savedState?.pdfDataURL || null;
  uploadedRillinesPdfDataURL = saved.rillinesPdfDataURL || savedState?.rillinesPdfDataURL || null;
  activeDesignTab = saved.tab || savedState?.tab || 'tool';

  el.innerHTML = `
    <h1 class="page-title">Ontwerp uw verpakking</h1>
    <p class="page-subtitle">Gebruik de ontwerptool of upload een eigen bestand</p>

    <div class="design-tabs" style="margin-bottom:24px">
      <button class="design-tab ${activeDesignTab === 'tool' ? 'active' : ''}" type="button" data-tab="tool">Ontwerptool</button>
      <button class="design-tab ${activeDesignTab === 'upload' ? 'active' : ''}" type="button" data-tab="upload">Bestand uploaden</button>
    </div>

    <div id="tab-tool" style="${activeDesignTab === 'tool' ? '' : 'display:none'}">
      <div id="app">
        <aside id="sidebar">
          <div id="sidebar-header"></div>

          <div class="side-section">
            <div class="side-label">Toevoegen</div>

            <button class="tool-btn" type="button" id="btn-logo">+ Logo uploaden</button>
            <input type="file" id="file-input" accept="image/*" style="display:none">

            <button class="tool-btn" type="button" id="btn-text">+ Tekst toevoegen</button>
          </div>

          <div class="side-section">
            <div class="side-label">Lettertype</div>
            <select id="font-select" class="font-select">
              ${AVAILABLE_FONTS.map(font => `
                <option value="${font.value}" style="font-family:${font.value}">${font.label}</option>
              `).join('')}
            </select>
          </div>

          <div class="side-section">
            <div class="side-label">Lettergrootte</div>
            <select id="font-size" class="font-select">
              ${[8, 10, 12, 14, 16, 18, 20, 24, 28, 32, 36, 42, 48, 56, 64, 72, 84, 96].map(size => `
                <option value="${size}" ${size === 20 ? 'selected' : ''}>${size} px</option>
              `).join('')}
            </select>
          </div>

          <div class="side-section">
            <div class="side-label">Elementkleur</div>
            <div class="color-row" id="color-swatches"></div>

            <div class="custom-color-row">
              <label for="custom-element-color">Eigen kleur</label>
              <input type="color"
                     id="custom-element-color"
                     class="custom-color-input"
                     value="${fabricActiveColor}">
            </div>
          </div>

          ${activePers?.allowBackgroundColor ? `
            <div class="side-section">
              <div class="side-label">Achtergrondkleur</div>
              <div class="color-row" id="background-color-swatches"></div>

              <div class="custom-color-row">
                <label for="custom-background-color">Eigen kleur</label>
                <input type="color"
                       id="custom-background-color"
                       class="custom-color-input"
                       value="${fabricBackgroundColor}">
              </div>
            </div>
          ` : ''}
        </aside>

        <section id="canvas-area">
          <div id="canvas-toolbar">
            <button class="tb-btn" type="button" id="btn-delete">Verwijder</button>
            <button class="tb-btn" type="button" id="btn-front">Voorgrond</button>
            <button class="tb-btn" type="button" id="btn-back">Achtergrond</button>
            <div class="tb-sep"></div>
            <button class="tb-btn" type="button" id="btn-undo">Ongedaan</button>
            <button class="tb-btn" type="button" id="btn-clear">Reset</button>
          </div>


          <div id="canvas-wrap">
            <div id="margin-warning">Object buiten marge</div>
            <canvas id="c"></canvas>

            <div class="canvas-zoom-controls" aria-label="Canvas zoom controls">
              <button class="canvas-zoom-btn" type="button" id="btn-canvas-zoom-out" aria-label="Uitzoomen">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                  <circle cx="7.5" cy="7.5" r="5.25" stroke="currentColor" stroke-width="1.8"/>
                  <path d="M11.5 11.5L15 15" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                  <path d="M5.25 7.5H9.75" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                </svg>
              </button>

              <button class="canvas-zoom-btn" type="button" id="btn-canvas-zoom-in" aria-label="Inzoomen">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                  <circle cx="7.5" cy="7.5" r="5.25" stroke="currentColor" stroke-width="1.8"/>
                  <path d="M11.5 11.5L15 15" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                  <path d="M5.25 7.5H9.75" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                  <path d="M7.5 5.25V9.75" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                </svg>
              </button>
            </div>
          </div>

          <div id="status">Selecteer een element om te bewerken. Klik en sleep om te verplaatsen.</div>
        </section>

        <aside id="layer-panel">
          <div id="layer-header">Layers</div>
          <div id="layer-list"></div>
        </aside>
      </div>

      <div
        id="fabric-image-dpi-warning"
        style="display:none;position:fixed;right:24px;top:160px;z-index:1000;width:min(320px,calc(100vw - 48px));padding:12px 14px;border-radius:10px;font-size:12px;line-height:1.45;box-shadow:0 10px 30px rgba(0,0,0,.12)"
      ></div>
    </div>

    <div id="tab-upload" style="${activeDesignTab === 'upload' ? '' : 'display:none'}">
      <div class="design-layout">
        <div>
          <div class="upload-zone" id="upload-zone">
            <input type="file" id="upload-input" accept=".png,.jpg,.jpeg,.pdf,.ai,.eps">
            <div class="upload-icon">📁</div>
            <div class="upload-title">Sleep uw bestand hierheen</div>
            <div class="upload-sub">of klik om te bladeren</div>
            <div class="upload-sub" style="margin-top:8px">PNG, JPG, PDF, AI, EPS. Minimaal 300 DPI aanbevolen.</div>
          </div>

          ${uploadedDataURL ? `
            <div style="margin-top:12px;padding:10px 14px;background:var(--green-light);border-radius:8px;
                        font-size:13px;color:var(--green-dark);display:flex;justify-content:space-between;align-items:center">
              <span>${escHtml(uploadedFileName || 'Bestand geüpload')}</span>
              <button onclick="clearUpload()" type="button" style="background:none;border:none;cursor:pointer;color:#C0392B;font-size:18px">×</button>
            </div>
          ` : ''}

          ${uploadedCheck ? `
            <div style="margin-top:10px;padding:10px 14px;background:${getUploadCheckBackground(uploadedCheck.status)};border-radius:8px;
                        font-size:12px;color:${getUploadCheckTextColor(uploadedCheck.status)}">
              ${escHtml(uploadedCheck.message || 'Upload gecontroleerd.')}
            </div>
          ` : ''}
        </div>

        <div>
          <div class="preview-box" id="preview-box">
            ${uploadedDataURL && uploadedDataURL.startsWith('data:image')
      ? `<img src="${uploadedDataURL}" alt="Preview">`
      : `<div class="preview-placeholder">${uploadedDataURL ? escHtml(uploadedFileName || 'Bestand') : 'Preview'}</div>`}
            <div class="preview-zoom" id="btn-zoom" ${!uploadedDataURL ? 'style="display:none"' : ''}>🔍</div>
          </div>
          <p style="font-size:12px;color:var(--text-3);margin-top:8px;text-align:center">Preview van uw bestand</p>
        </div>
      </div>
    </div>

    <div id="design-error" style="color:#C0392B;font-size:13px;display:none;margin-top:16px">
      Maak een ontwerp of upload een bestand om verder te gaan.
    </div>

    <div class="flow-nav">
      <button class="btn btn-outline" type="button" onclick="navigateTo('options')">← Terug</button>
      <button class="btn btn-green" type="button" id="btn-design-next">Verder →</button>
    </div>
  `;

  bindDesignTabs(product, activePers, savedState, stateKey);
  bindUploadZone(stateKey, activePers, product);
  bindDesignNextButton(product, activePers, stateKey);

  document.getElementById('btn-zoom')?.addEventListener('click', () => {
    if (uploadedDataURL) {
      window.open(uploadedDataURL, '_blank');
    }
  });

  if (activeDesignTab === 'tool') {
    scheduleFabricInit(product, activePers, savedState, stateKey);
  }
}

function bindDesignTabs(product, activePers, savedState, stateKey) {
  document.querySelectorAll('.design-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      activeDesignTab = tab.dataset.tab;

      document.querySelectorAll('.design-tab').forEach(item => item.classList.remove('active'));
      tab.classList.add('active');

      const toolTab = document.getElementById('tab-tool');
      const uploadTab = document.getElementById('tab-upload');

      if (toolTab) {
        toolTab.style.display = activeDesignTab === 'tool' ? '' : 'none';
      }

      if (uploadTab) {
        uploadTab.style.display = activeDesignTab === 'upload' ? '' : 'none';
      }

      persistDesignState(stateKey, { tab: activeDesignTab });

      if (activeDesignTab === 'tool') {
        scheduleFabricInit(product, activePers, savedState, stateKey);
      }
    });
  });
}

function bindUploadZone(stateKey, activePers, product) {
  const zone = document.getElementById('upload-zone');
  const input = document.getElementById('upload-input');

  if (!zone || !input) {
    return;
  }

  zone.addEventListener('click', () => input.click());

  zone.addEventListener('dragover', event => {
    event.preventDefault();
    zone.classList.add('dragover');
  });

  zone.addEventListener('dragleave', () => {
    zone.classList.remove('dragover');
  });

  zone.addEventListener('drop', event => {
    event.preventDefault();
    zone.classList.remove('dragover');

    const file = event.dataTransfer.files?.[0];

    if (file) {
      handleUpload(file, stateKey, activePers, product);
    }
  });

  input.addEventListener('change', event => {
    const file = event.target.files?.[0];

    if (file) {
      handleUpload(file, stateKey, activePers, product);
    }
  });
}

function bindDesignNextButton(product, activePers, stateKey) {
  document.getElementById('btn-design-next')?.addEventListener('click', () => {
    const error = document.getElementById('design-error');

    if (activeDesignTab === 'upload') {
      if (!uploadedDataURL) {
        if (error) {
          error.style.display = 'block';
        }

        return;
      }

      const designData = {
        dataURL: uploadedDataURL,
        pdfDataURL: uploadedPdfDataURL || (uploadedDataURL.startsWith('data:application/pdf') ? uploadedDataURL : ''),
        rillinesPdfDataURL: uploadedRillinesPdfDataURL || '',
        fileName: uploadedFileName,
        tab: 'upload',
        source: 'upload',
        uploadCheck: uploadedCheck,
        prepressWarnings: getUploadPrepressWarnings(uploadedCheck),
      };

      Session.setDesign(designData);
      persistDesignState(stateKey, designData);
    } else {
      if (!fabricCanvas) {
        if (error) {
          error.textContent = 'De ontwerptool is nog niet geladen. Probeer het opnieuw.';
          error.style.display = 'block';
        }

        return;
      }

      const snapshot = snapshotCanvas(fabricCanvas, product, activePers);
      const prepressWarnings = collectCanvasPrepressWarnings(fabricCanvas, activePers, product);

      Session.setDesign({
        dataURL: snapshot.dataURL,
        pdfDataURL: snapshot.pdfDataURL,
        rillinesPdfDataURL: snapshot.rillinesPdfDataURL,
        tab: 'tool',
        source: 'fabric',
        fabricJSON: snapshot.json,
        backgroundColor: snapshot.backgroundColor,
        prepressWarnings,
        uploadCheck: null,
      });

      persistDesignState(stateKey, {
        dataURL: snapshot.dataURL,
        pdfDataURL: snapshot.pdfDataURL,
        rillinesPdfDataURL: snapshot.rillinesPdfDataURL,
        fabricJSON: snapshot.json,
        backgroundColor: snapshot.backgroundColor,
        tab: 'tool',
        prepressWarnings,
        uploadCheck: null,
      });
    }

    if (error) {
      error.style.display = 'none';
    }

    navigateTo('review');
  });
}

function bindFontSelector(canvas, stateKey) {
  const select = document.getElementById('font-select');
  const preview = document.getElementById('font-preview');

  if (!select) {
    return;
  }

  select.addEventListener('change', () => {
    const fontValue = select.value;

    if (preview) {
      preview.style.fontFamily = fontValue;
    }

    const object = canvas.getActiveObject();

    if (object && object.type === 'i-text') {
      object.set('fontFamily', fontValue);
      canvas.renderAll();
      fabricSaveHistory();
      autoSaveCanvasState(stateKey);
    }
  });

  canvas.on('selection:created', syncFontControls);
  canvas.on('selection:updated', syncFontControls);

  function syncFontControls() {
    const object = canvas.getActiveObject();

    if (object && object.type === 'i-text') {
      const currentFont = object.fontFamily || 'Georgia';
      const match = AVAILABLE_FONTS.find(font => font.value === currentFont);

      if (match) {
        select.value = match.value;
      }

      if (preview) {
        preview.style.fontFamily = currentFont;
      }

      syncFontSizeControls(object);
    }
  }
}

function bindFontSizeControl(canvas, stateKey) {
  const select = document.getElementById('font-size');

  if (!select) {
    return;
  }

  select.addEventListener('change', event => {
    const value = parseInt(event.target.value, 10);
    const object = canvas.getActiveObject();

    if (object && object.type === 'i-text' && !isGuideObject(object)) {
      object.set('fontSize', value);
      canvas.renderAll();
      fabricSaveHistory();
      updateLayerPanel();
      autoSaveCanvasState(stateKey);
    }
  });

  canvas.on('selection:created', event => syncFontSizeControls(event.selected?.[0]));
  canvas.on('selection:updated', event => syncFontSizeControls(event.selected?.[0]));
}

function syncFontSizeControls(object) {
  const select = document.getElementById('font-size');

  if (!select || !object || object.type !== 'i-text') {
    return;
  }

  const fontSize = Math.round(object.fontSize || 20);
  const availableSizes = [...select.options].map(option => Number(option.value));
  const closestSize = availableSizes.reduce((closest, size) => {
    return Math.abs(size - fontSize) < Math.abs(closest - fontSize) ? size : closest;
  }, availableSizes[0]);

  select.value = String(closestSize);
}

function getResponsiveCanvasSize(activePers, product) {
  const printWidthPx = activePers?.width_px || product.width_px || 1181;
  const printHeightPx = activePers?.height_px || product.height_px || 827;
  const canvasWrap = document.getElementById('canvas-wrap');

  const fallbackWidth = Math.max(280, window.innerWidth - 560);
  const fallbackHeight = Math.max(240, window.innerHeight - 360);

  const availableWidth = canvasWrap
    ? Math.max(280, canvasWrap.clientWidth - 32)
    : fallbackWidth;

  const availableHeight = canvasWrap
    ? Math.max(240, canvasWrap.clientHeight - 32)
    : fallbackHeight;

  const scale = Math.min(
    1,
    availableWidth / printWidthPx,
    availableHeight / printHeightPx
  );

  return {
    width: Math.max(1, Math.floor(printWidthPx * scale)),
    height: Math.max(1, Math.floor(printHeightPx * scale)),
    scale,
    printWidthPx,
    printHeightPx,
  };
}

function applyCanvasZoom() {
  const container = document.querySelector('#canvas-wrap .canvas-container');

  if (!container) {
    return;
  }

  container.style.transform = `scale(${canvasZoom})`;
  container.style.transformOrigin = 'center center';
}

function setCanvasZoom(nextZoom) {
  canvasZoom = Math.min(CANVAS_ZOOM_MAX, Math.max(CANVAS_ZOOM_MIN, nextZoom));
  applyCanvasZoom();
}

function bindCanvasZoomControls() {
  document.getElementById('btn-canvas-zoom-in')?.addEventListener('click', () => {
    setCanvasZoom(canvasZoom + CANVAS_ZOOM_STEP);
  });

  document.getElementById('btn-canvas-zoom-out')?.addEventListener('click', () => {
    setCanvasZoom(canvasZoom - CANVAS_ZOOM_STEP);
  });
}

function scheduleFabricInit(product, activePers, savedState, stateKey) {
  fabricInitToken += 1;
  const token = fabricInitToken;

  if (fabricInitTimer) {
    clearTimeout(fabricInitTimer);
  }

  fabricInitTimer = setTimeout(() => {
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        if (token !== fabricInitToken) {
          return;
        }

        const canvasWrap = document.getElementById('canvas-wrap');
        const canvasElement = document.getElementById('c');

        if (!canvasWrap || !canvasElement) {
          return;
        }

        if (canvasWrap.clientWidth <= 0 || canvasWrap.clientHeight <= 0) {
          scheduleFabricInit(product, activePers, savedState, stateKey);
          return;
        }

        initFabricTool(product, activePers, savedState, stateKey, token);
      });
    });
  }, 60);
}

function destroyFabricCanvas() {
  if (fabricCanvas) {
    try {
      fabricCanvas.off();
      fabricCanvas.dispose();
    } catch (error) {
      console.warn('Fabric canvas opruimen mislukt', error);
    }

    fabricCanvas = null;
  }

  const canvasWrap = document.getElementById('canvas-wrap');

  if (!canvasWrap) {
    return;
  }

  canvasWrap.querySelectorAll('.canvas-container').forEach(container => {
    const nestedCanvas = container.querySelector('canvas#c');

    if (nestedCanvas) {
      canvasWrap.appendChild(nestedCanvas);
    }

    container.remove();
  });

  const canvas = document.getElementById('c');

  if (canvas) {
    canvas.removeAttribute('style');
    canvas.removeAttribute('width');
    canvas.removeAttribute('height');
    canvas.className = '';
  }
}

function initFabricTool(product, activePers, savedState, stateKey, token = fabricInitToken) {
  if (!window.fabric) {
    console.warn('Fabric.js niet geladen.');
    return;
  }

  const canvasElement = document.getElementById('c');
  const canvasWrap = document.getElementById('canvas-wrap');

  if (!canvasElement || !canvasWrap) {
    return;
  }

  destroyFabricCanvas();

  if (token !== fabricInitToken) {
    return;
  }

  fabricHistory = [];
  canvasZoom = 1;
  fabricActiveColor = '#1D9E75';
  fabricBackgroundColor = savedState?.backgroundColor || activePers?.backgroundColor || '#b7bdb8';

  const display = getResponsiveCanvasSize(activePers, product);
  const canvasWidth = display.width;
  const canvasHeight = display.height;
  const marginPx = activePers?.margin_px || product.margin_px || 20;
  const margin = marginPx * display.scale;
  const clipShape = activePers?.clipShape || null;

  fabricCanvas = new fabric.Canvas('c', {
    width: canvasWidth,
    height: canvasHeight,
    selection: true,
    backgroundColor: fabricBackgroundColor,
    preserveObjectStacking: true,
  });

  window._currentDesignStateKey = stateKey;

  bindFabricDocumentHandlers();
  applyCanvasClipPath(clipShape, canvasWidth, canvasHeight);
  renderColorSwatches();
  renderBackgroundColorSwatches(activePers, stateKey);

  loadBackgroundImage(fabricCanvas, activePers, product, canvasWidth, canvasHeight);

  restoreCanvasStateOrDefault(
    fabricCanvas,
    savedState,
    canvasHeight,
    margin,
    canvasWidth,
    canvasHeight,
    activePers,
    product
  );

  bindFabricEvents(fabricCanvas, margin, canvasWidth, canvasHeight, stateKey, activePers, product);
  bindFabricButtons(fabricCanvas, margin, canvasWidth, canvasHeight, stateKey, activePers, product);

  fabricSaveHistory();
  updateLayerPanel();
  updateFabricImageDpiWarning(fabricCanvas, activePers, product);

  bindCanvasZoomControls();
  applyCanvasZoom();

  setTimeout(() => {
    if (fabricCanvas && token === fabricInitToken) {
      redrawGuides(fabricCanvas, activePers, product, margin, canvasWidth, canvasHeight);
      updateFabricImageDpiWarning(fabricCanvas, activePers, product);
      applyCanvasZoom();
    }
  }, 120);
}

function bindFabricDocumentHandlers() {
  if (window._fabricMouseUpHandler) {
    document.removeEventListener('mouseup', window._fabricMouseUpHandler);
  }

  window._fabricMouseUpHandler = () => {
    if (!fabricCanvas) {
      return;
    }

    const transform = fabricCanvas._currentTransform;

    if (transform) {
      fabricCanvas._currentTransform = null;
      fabricCanvas.setCursor(fabricCanvas.defaultCursor);
      fabricCanvas.renderAll();
    }
  };

  document.addEventListener('mouseup', window._fabricMouseUpHandler);

  if (window._fabricKeyHandler) {
    document.removeEventListener('keydown', window._fabricKeyHandler);
  }

  window._fabricKeyHandler = event => {
    if (event.key !== 'Backspace' && event.key !== 'Delete') {
      return;
    }

    const object = fabricCanvas?.getActiveObject();

    if (object && !isGuideObject(object) && !(object.type === 'i-text' && object.isEditing)) {
      fabricCanvas.remove(object);
      updateFabricImageDpiWarning(
        fabricCanvas,
        window._currentDesignGuideState?.activePers,
        window._currentDesignGuideState?.product
      );
      fabricSaveHistory();
      updateLayerPanel();
      autoSaveCanvasState(window._currentDesignStateKey);
    }
  };

  document.addEventListener('keydown', window._fabricKeyHandler);
}

function applyCanvasClipPath(clipShape, canvasWidth, canvasHeight) {
  const canvasEl = document.querySelector('#canvas-wrap canvas');

  if (!canvasEl) {
    return;
  }

  canvasEl.style.clipPath = '';
  canvasEl.style.borderRadius = '';

  if (!clipShape) {
    return;
  }

  canvasEl.style.clipPath = clipShape;
  canvasEl.style.borderRadius = clipShape.startsWith('circle') ? '50%' : '4px';

  if (clipShape.startsWith('circle')) {
    const radius = Math.min(canvasWidth, canvasHeight) / 2;

    fabricCanvas.clipPath = new fabric.Circle({
      radius,
      left: canvasWidth / 2 - radius,
      top: canvasHeight / 2 - radius,
      absolutePositioned: true,
    });
  }
}

function renderColorSwatches() {
  const colors = ['#1D9E75', '#ffffff', '#2c2c2a', '#e63946', '#f4a261', '#457b9d', '#f1c453', '#9d4edd'];
  const swatchContainer = document.getElementById('color-swatches');

  if (!swatchContainer) {
    return;
  }

  swatchContainer.innerHTML = '';

  colors.forEach((color, index) => {
    const swatch = document.createElement('div');
    swatch.className = `color-swatch${index === 0 ? ' active' : ''}`;
    swatch.style.background = color;

    swatch.addEventListener('click', () => {
      swatchContainer.querySelectorAll('.color-swatch').forEach(item => item.classList.remove('active'));
      swatch.classList.add('active');
      fabricActiveColor = color;
      applyToSelected('fill', color);
    });

    swatchContainer.appendChild(swatch);
  });

  const customColorInput = document.getElementById('custom-element-color');

  if (customColorInput) {
    customColorInput.value = fabricActiveColor;

    customColorInput.addEventListener('input', event => {
      const color = event.target.value;
      fabricActiveColor = color;

      swatchContainer.querySelectorAll('.color-swatch').forEach(item => {
        item.classList.remove('active');
      });

      applyToSelected('fill', color);
    });
  }
}

function renderBackgroundColorSwatches(activePers, stateKey) {
  if (!activePers?.allowBackgroundColor) {
    return;
  }

  const swatchContainer = document.getElementById('background-color-swatches');

  if (!swatchContainer) {
    return;
  }

  const colors = [
    '#b7bdb8',
    '#ffffff',
    '#F7F4EE',
    '#EDF2ED',
    '#FDF4DC',
    '#5C7A5C',
    '#C9A84C',
    '#2A2A22',
  ];

  swatchContainer.innerHTML = '';

  colors.forEach(color => {
    const swatch = document.createElement('div');
    swatch.className = `color-swatch${color.toLowerCase() === fabricBackgroundColor.toLowerCase() ? ' active' : ''}`;
    swatch.style.background = color;

    swatch.addEventListener('click', () => {
      setCanvasBackgroundColor(color, stateKey);

      swatchContainer.querySelectorAll('.color-swatch').forEach(item => {
        item.classList.remove('active');
      });

      swatch.classList.add('active');

      const customBackgroundInput = document.getElementById('custom-background-color');

      if (customBackgroundInput) {
        customBackgroundInput.value = color;
      }
    });

    swatchContainer.appendChild(swatch);
  });

  const customBackgroundInput = document.getElementById('custom-background-color');

  if (customBackgroundInput) {
    customBackgroundInput.value = fabricBackgroundColor;

    customBackgroundInput.addEventListener('input', event => {
      setCanvasBackgroundColor(event.target.value, stateKey);

      swatchContainer.querySelectorAll('.color-swatch').forEach(item => {
        item.classList.remove('active');
      });
    });
  }
}

function setCanvasBackgroundColor(color, stateKey) {
  fabricBackgroundColor = color;

  if (!fabricCanvas) {
    return;
  }

  if (typeof fabricCanvas.setBackgroundColor === 'function') {
    fabricCanvas.setBackgroundColor(color, fabricCanvas.renderAll.bind(fabricCanvas));
  } else {
    fabricCanvas.backgroundColor = color;
    fabricCanvas.renderAll();
  }

  redrawGuidesFromCurrentState();
  autoSaveCanvasState(stateKey);

  persistDesignState(stateKey, {
    backgroundColor: color,
  });
}

function drawMarginRect(canvas, margin, canvasWidth, canvasHeight, isWarning = false) {
  canvas.getObjects()
    .filter(object => object._isMargin && !object._isBlockedZone)
    .forEach(object => canvas.remove(object));

  const marginColor = isWarning
    ? '#C0392B'
    : getContrastingGuideColor(fabricBackgroundColor);

  const marginRect = new fabric.Rect({
    left: margin,
    top: margin,
    width: Math.max(1, canvasWidth - margin * 2),
    height: Math.max(1, canvasHeight - margin * 2),
    fill: 'transparent',
    stroke: marginColor,
    strokeWidth: isWarning ? 2.5 : 1.75,
    strokeDashArray: [6, 4],
    selectable: false,
    evented: false,
    excludeFromExport: true,
    _isMargin: true,
    _isGuide: true,
    _guideMeta: {
      margin,
      canvasWidth,
      canvasHeight,
    },
  });

  canvas.add(marginRect);
}

function drawBlockedZones(canvas, activePers, product, canvasWidth, canvasHeight) {
  const zones = Array.isArray(activePers?.blockedZones) ? activePers.blockedZones : [];

  canvas.getObjects()
    .filter(object => object._isBlockedZone)
    .forEach(object => canvas.remove(object));

  if (!zones.length) {
    canvas.renderAll();
    return;
  }

  zones.forEach(zone => {
    if (zone.type === 'circle') {
      const circleData = getBlockedCircleCanvasData(zone, activePers, product, canvasWidth, canvasHeight);

      if (!circleData) {
        return;
      }

      const safeCircle = new fabric.Circle({
        left: circleData.cx - circleData.safeRadius,
        top: circleData.cy - circleData.safeRadius,
        radius: circleData.safeRadius,
        fill: 'rgba(232, 134, 10, 0.14)',
        stroke: '#E8860A',
        strokeWidth: 2,
        strokeDashArray: [8, 5],
        selectable: false,
        evented: false,
        objectCaching: false,
        excludeFromExport: true,
        _isMargin: true,
        _isGuide: true,
        _isBlockedZone: true,
      });

      const holeCircle = new fabric.Circle({
        left: circleData.cx - circleData.holeRadius,
        top: circleData.cy - circleData.holeRadius,
        radius: circleData.holeRadius,
        fill: 'rgba(192, 57, 43, 0.24)',
        stroke: '#C0392B',
        strokeWidth: 2,
        strokeDashArray: [4, 3],
        selectable: false,
        evented: false,
        objectCaching: false,
        excludeFromExport: true,
        _isMargin: true,
        _isGuide: true,
        _isBlockedZone: true,
      });

      canvas.add(safeCircle);
      canvas.add(holeCircle);
      return;
    }

    if (zone.type === 'rect') {
      const rectData = getBlockedRectCanvasData(zone, activePers, product, canvasWidth, canvasHeight);

      if (!rectData) {
        return;
      }

      const safeRect = new fabric.Rect({
        left: rectData.safeLeft,
        top: rectData.safeTop,
        width: rectData.safeWidth,
        height: rectData.safeHeight,
        fill: 'rgba(232, 134, 10, 0.14)',
        stroke: '#E8860A',
        strokeWidth: 2,
        strokeDashArray: [8, 5],
        selectable: false,
        evented: false,
        objectCaching: false,
        excludeFromExport: true,
        _isMargin: true,
        _isGuide: true,
        _isBlockedZone: true,
      });

      const blockedRect = new fabric.Rect({
        left: rectData.left,
        top: rectData.top,
        width: rectData.width,
        height: rectData.height,
        fill: 'rgba(192, 57, 43, 0.18)',
        stroke: '#C0392B',
        strokeWidth: 2,
        strokeDashArray: [4, 3],
        selectable: false,
        evented: false,
        objectCaching: false,
        excludeFromExport: true,
        _isMargin: true,
        _isGuide: true,
        _isBlockedZone: true,
      });

      canvas.add(safeRect);
      canvas.add(blockedRect);
      return;
    }

    if (zone.type === 'line') {
      const lineData = getBlockedLineCanvasData(zone, activePers, product, canvasWidth, canvasHeight);

      if (!lineData) {
        return;
      }

      const safeZone = createCenteredLineSafeZone(lineData);

      if (safeZone) {
        canvas.add(safeZone);
      }

      const foldLine = new fabric.Line(
        [lineData.x1, lineData.y1, lineData.x2, lineData.y2],
        {
          stroke: '#C0392B',
          strokeWidth: Math.max(1.5, lineData.lineWidth),
          strokeDashArray: [2, 1.5],
          selectable: false,
          evented: false,
          objectCaching: false,
          excludeFromExport: true,
          _isMargin: true,
          _isGuide: true,
          _isBlockedZone: true,
        }
      );

      canvas.add(foldLine);
    }
  });

  bringGuidesToFront(canvas);
  canvas.renderAll();
}

function createCenteredLineSafeZone(lineData) {
  const deltaX = lineData.x2 - lineData.x1;
  const deltaY = lineData.y2 - lineData.y1;
  const lineLength = Math.sqrt(deltaX * deltaX + deltaY * deltaY);

  if (!lineLength) {
    return null;
  }

  const centerX = (lineData.x1 + lineData.x2) / 2;
  const centerY = (lineData.y1 + lineData.y2) / 2;
  const angle = Math.atan2(deltaY, deltaX) * 180 / Math.PI;

  return new fabric.Rect({
    left: centerX,
    top: centerY,
    width: lineLength,
    height: lineData.safeWidth,
    originX: 'center',
    originY: 'center',
    angle,
    fill: 'rgba(232, 134, 10, 0.18)',
    stroke: '#E8860A',
    strokeWidth: 1,
    strokeDashArray: [8, 5],
    selectable: false,
    evented: false,
    objectCaching: false,
    excludeFromExport: true,
    opacity: 0.75,
    _isMargin: true,
    _isGuide: true,
    _isBlockedZone: true,
  });
}

function redrawGuides(canvas, activePers, product, margin, canvasWidth, canvasHeight, isWarning = false) {
  if (!canvas) {
    return;
  }

  removeGuideObjects(canvas);
  drawMarginRect(canvas, margin, canvasWidth, canvasHeight, isWarning);
  drawBlockedZones(canvas, activePers, product, canvasWidth, canvasHeight);
  bringGuidesToFront(canvas);
  canvas.renderAll();

  window._currentDesignGuideState = {
    activePers,
    product,
    margin,
    canvasWidth,
    canvasHeight,
  };
}

function redrawGuidesFromCurrentState(isWarning = false) {
  const state = window._currentDesignGuideState;

  if (!fabricCanvas || !state) {
    return;
  }

  redrawGuides(
    fabricCanvas,
    state.activePers,
    state.product,
    state.margin,
    state.canvasWidth,
    state.canvasHeight,
    isWarning
  );
}

function bringGuidesToFront(canvas) {
  canvas.getObjects()
    .filter(object => isGuideObject(object))
    .forEach(object => {
      object.selectable = false;
      object.evented = false;
      object.hoverCursor = 'default';
      canvas.bringToFront(object);
    });
}

function removeGuideObjects(canvas) {
  canvas.getObjects()
    .filter(object => isGuideObject(object))
    .forEach(object => canvas.remove(object));
}

function isGuideObject(object) {
  return Boolean(object?._isGuide || object?._isBlockedZone || object?._isMargin);
}

function getContrastingGuideColor(backgroundColor) {
  const hex = normalizeHexColor(backgroundColor);

  if (!hex) {
    return '#2A2A22';
  }

  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  const brightness = (r * 299 + g * 587 + b * 114) / 1000;

  return brightness > 170 ? '#2A2A22' : '#FFFFFF';
}

function normalizeHexColor(value) {
  if (!value || typeof value !== 'string') {
    return '';
  }

  if (/^#[0-9A-Fa-f]{6}$/.test(value)) {
    return value;
  }

  if (/^#[0-9A-Fa-f]{3}$/.test(value)) {
    return `#${value[1]}${value[1]}${value[2]}${value[2]}${value[3]}${value[3]}`;
  }

  return '';
}

function getBlockedCircleCanvasData(zone, activePers, product, canvasWidth, canvasHeight) {
  const widthMm = Number(activePers?.width_mm || product?.width_mm || 0);
  const heightMm = Number(activePers?.height_mm || product?.height_mm || 0);

  if (!widthMm || !heightMm) {
    return null;
  }

  const xMm = Number(zone.x_mm || 0);
  const yMm = Number(zone.y_mm || 0);
  const diameterMm = Number(zone.diameter_mm || 0);
  const marginMm = Number(zone.margin_mm || 0);

  if (!diameterMm) {
    return null;
  }

  const pxPerMmX = canvasWidth / widthMm;
  const pxPerMmY = canvasHeight / heightMm;
  const averagePxPerMm = (pxPerMmX + pxPerMmY) / 2;

  const holeRadius = (diameterMm / 2) * averagePxPerMm;
  const safeRadius = holeRadius + marginMm * averagePxPerMm;

  return {
    cx: xMm * pxPerMmX,
    cy: yMm * pxPerMmY,
    holeRadius,
    safeRadius,
  };
}

function getBlockedRectCanvasData(zone, activePers, product, canvasWidth, canvasHeight) {
  const widthMm = Number(activePers?.width_mm || product?.width_mm || 0);
  const heightMm = Number(activePers?.height_mm || product?.height_mm || 0);

  if (!widthMm || !heightMm) {
    return null;
  }

  const xMm = Number(zone.x_mm || 0);
  const yMm = Number(zone.y_mm || 0);
  const rectWidthMm = Number(zone.width_mm || 0);
  const rectHeightMm = Number(zone.height_mm || 0);
  const marginMm = Number(zone.margin_mm || 0);

  if (!rectWidthMm || !rectHeightMm) {
    return null;
  }

  const pxPerMmX = canvasWidth / widthMm;
  const pxPerMmY = canvasHeight / heightMm;

  const left = xMm * pxPerMmX;
  const top = yMm * pxPerMmY;
  const width = rectWidthMm * pxPerMmX;
  const height = rectHeightMm * pxPerMmY;
  const marginX = marginMm * pxPerMmX;
  const marginY = marginMm * pxPerMmY;

  return {
    left,
    top,
    width,
    height,
    safeLeft: left - marginX,
    safeTop: top - marginY,
    safeWidth: width + marginX * 2,
    safeHeight: height + marginY * 2,
  };
}

function getBlockedLineCanvasData(zone, activePers, product, canvasWidth, canvasHeight) {
  const widthMm = Number(activePers?.width_mm || product?.width_mm || 0);
  const heightMm = Number(activePers?.height_mm || product?.height_mm || 0);

  if (!widthMm || !heightMm) {
    return null;
  }

  let x1Mm = Number(zone.x1_mm || 0);
  let y1Mm = Number(zone.y1_mm || 0);
  let x2Mm = Number(zone.x2_mm || 0);
  let y2Mm = Number(zone.y2_mm || 0);
  const lineWidthMm = Number(zone.line_width_mm || 0.3);
  const marginMm = Number(zone.margin_mm || 0);

  if (x1Mm === x2Mm && y1Mm === y2Mm) {
    return null;
  }

  const deltaXmm = Math.abs(x2Mm - x1Mm);
  const deltaYmm = Math.abs(y2Mm - y1Mm);

  if (deltaYmm <= 0.01) {
    const centerYmm = (y1Mm + y2Mm) / 2;
    x1Mm = 0;
    x2Mm = widthMm;
    y1Mm = centerYmm;
    y2Mm = centerYmm;
  } else if (deltaXmm <= 0.01) {
    const centerXmm = (x1Mm + x2Mm) / 2;
    x1Mm = centerXmm;
    x2Mm = centerXmm;
    y1Mm = 0;
    y2Mm = heightMm;
  }

  const pxPerMmX = canvasWidth / widthMm;
  const pxPerMmY = canvasHeight / heightMm;
  const averagePxPerMm = (pxPerMmX + pxPerMmY) / 2;

  return {
    x1: x1Mm * pxPerMmX,
    y1: y1Mm * pxPerMmY,
    x2: x2Mm * pxPerMmX,
    y2: y2Mm * pxPerMmY,
    lineWidth: Math.max(1, lineWidthMm * averagePxPerMm),
    safeWidth: Math.max(3, (lineWidthMm + marginMm * 2) * averagePxPerMm),
    safeRadius: Math.max(1.5, ((lineWidthMm / 2) + marginMm) * averagePxPerMm),
  };
}

function loadBackgroundImage(canvas, activePers, product, canvasWidth, canvasHeight) {
  if (activePers?.allowBackgroundColor) {
    return;
  }

  const bgImg = getPersonalisationImageSrc(activePers, product);

  if (!bgImg) {
    return;
  }

  fabric.Image.fromURL(bgImg, image => {
    const scale = Math.min(
      canvasWidth / image.width,
      canvasHeight / image.height
    );

    image.set({
      originX: 'center',
      originY: 'center',
      left: canvasWidth / 2,
      top: canvasHeight / 2,
      scaleX: scale,
      scaleY: scale,
    });

    canvas.setBackgroundImage(image, () => {
      canvas.renderAll();
    });
  }, {
    crossOrigin: 'anonymous',
  });
}

function restoreCanvasStateOrDefault(canvas, savedState, canvasHeight, margin, canvasWidth, canvasHeightValue, activePers, product) {
  const redrawAfterRestore = () => {
    redrawGuides(canvas, activePers, product, margin, canvasWidth, canvasHeightValue);
    restoreFabricImageUploadMeta(canvas);
    updateFabricImageDpiWarning(canvas, activePers, product);
    updateLayerPanel();
  };

  if (savedState?.fabricJSON) {
    try {
      canvas.loadFromJSON(savedState.fabricJSON, () => {
        removeGuideObjects(canvas);
        redrawAfterRestore();
      });
      return;
    } catch (error) {
      console.warn('Canvas state herstellen mislukt', error);
    }
  }

  addDefaultText(canvas, canvasHeight);
  redrawAfterRestore();
}

function addDefaultText(canvas, canvasHeight) {
  const selectedFont = document.getElementById('font-select')?.value || 'Georgia';

  const demo = new fabric.IText('Jouw bedrijfsnaam', {
    left: 60,
    top: Math.round(canvasHeight * 0.65),
    fontSize: 18,
    fill: '#ffffff',
    fontFamily: selectedFont,
    editable: true,
    opacity: 0.9,
  });

  canvas.add(demo);
  canvas.renderAll();
  fabricSaveHistory();
  updateLayerPanel();
}

function isCenterSnappableObject(object) {
  return object &&
    object.type === 'image' &&
    !isGuideObject(object);
}

function getCanvasCenterPoint(canvas) {
  return new fabric.Point(
    canvas.getWidth() / 2,
    canvas.getHeight() / 2
  );
}

function getCenterSnapThreshold(canvas) {
  const zoom = typeof canvas.getZoom === 'function' ? canvas.getZoom() || 1 : 1;

  return CENTER_SNAP_THRESHOLD_PX / zoom;
}

function applyCenterSnap(canvas, object) {
  if (!canvas || !isCenterSnappableObject(object)) {
    removeCenterSnapGuides(canvas);
    return;
  }

  const canvasCenter = getCanvasCenterPoint(canvas);
  const objectCenter = object.getCenterPoint();
  const threshold = getCenterSnapThreshold(canvas);

  const shouldSnapX = Math.abs(objectCenter.x - canvasCenter.x) <= threshold;
  const shouldSnapY = Math.abs(objectCenter.y - canvasCenter.y) <= threshold;

  if (!shouldSnapX && !shouldSnapY) {
    removeCenterSnapGuides(canvas);
    return;
  }

  const snappedCenter = new fabric.Point(
    shouldSnapX ? canvasCenter.x : objectCenter.x,
    shouldSnapY ? canvasCenter.y : objectCenter.y
  );

  object.setPositionByOrigin(snappedCenter, 'center', 'center');
  object.setCoords();

  renderCenterSnapGuides(canvas, {
    showVertical: shouldSnapX,
    showHorizontal: shouldSnapY,
  });
}

function renderCenterSnapGuides(canvas, { showVertical, showHorizontal }) {
  if (!canvas) {
    return;
  }

  removeCenterSnapGuides(canvas);

  const centerX = canvas.getWidth() / 2;
  const centerY = canvas.getHeight() / 2;
  const guideObjects = [];

  if (showVertical) {
    guideObjects.push(new fabric.Line(
      [centerX, 0, centerX, canvas.getHeight()],
      getCenterGuideObjectOptions()
    ));
  }

  if (showHorizontal) {
    guideObjects.push(new fabric.Line(
      [0, centerY, canvas.getWidth(), centerY],
      getCenterGuideObjectOptions()
    ));
  }

  guideObjects.forEach(guide => {
    canvas.add(guide);
    guide.bringToFront();
  });

  canvas._centerSnapGuides = guideObjects;
  canvas.requestRenderAll();
}

function getCenterGuideObjectOptions() {
  return {
    stroke: CENTER_GUIDE_COLOR,
    strokeWidth: CENTER_GUIDE_STROKE_WIDTH,
    strokeDashArray: CENTER_GUIDE_DASH,
    selectable: false,
    evented: false,
    objectCaching: false,
    excludeFromExport: true,
    _isGuide: true,
    _isCenterGuide: true,
  };
}

function removeCenterSnapGuides(canvas) {
  if (!canvas || !Array.isArray(canvas._centerSnapGuides)) {
    return;
  }

  canvas._centerSnapGuides.forEach(guide => {
    if (canvas.getObjects().includes(guide)) {
      canvas.remove(guide);
    }
  });

  canvas._centerSnapGuides = [];
  canvas.requestRenderAll();
}

function bindFabricEvents(canvas, margin, canvasWidth, canvasHeight, stateKey, activePers, product) {
  const checkMargin = object => {
    if (!object || isGuideObject(object)) {
      return;
    }

    const warning = document.getElementById('margin-warning');

    if (!warning) {
      return;
    }

    const outsideOuterMargin = isOutsideMargin(object, margin, canvasWidth, canvasHeight);
    const overlapsBlockedZone = isObjectOverlappingBlockedZones(object, activePers, product, canvasWidth, canvasHeight);
    const hasWarning = outsideOuterMargin || overlapsBlockedZone;

    warning.textContent = overlapsBlockedZone
      ? 'Object valt over uitsparing'
      : 'Object buiten marge';

    warning.style.display = hasWarning ? 'flex' : 'none';
    redrawGuides(canvas, activePers, product, margin, canvasWidth, canvasHeight, hasWarning);
  };

  canvas.on('object:moving', event => {
    checkMargin(event.target);
    applyCenterSnap(canvas, event.target);
    bringGuidesToFront(canvas);
  });

  canvas.on('object:rotating', event => {
    checkMargin(event.target);
    removeCenterSnapGuides(canvas);
    bringGuidesToFront(canvas);
  });

  canvas.on('object:scaling', event => {
    checkMargin(event.target);
    applyCenterSnap(canvas, event.target);
    updateFabricImageDpiWarning(canvas, activePers, product);
    bringGuidesToFront(canvas);
  });

  canvas.on('object:modified', event => {
    removeCenterSnapGuides(canvas);
    checkMargin(event.target);
    updateFabricImageDpiWarning(canvas, activePers, product);
    bringGuidesToFront(canvas);
  });

  canvas.on('text:changed', event => {
    checkMargin(event.target);
    fabricSaveHistory();
    updateLayerPanel();
    autoSaveCanvasState(stateKey);
  });

  canvas.on('object:moved', () => {
    removeCenterSnapGuides(canvas);

    const warning = document.getElementById('margin-warning');

    if (warning) {
      warning.style.display = 'none';
    }

    redrawGuides(canvas, activePers, product, margin, canvasWidth, canvasHeight);
    fabricSaveHistory();
    autoSaveCanvasState(stateKey);
  });

  canvas.on('object:modified', () => {
    removeCenterSnapGuides(canvas);
    redrawGuides(canvas, activePers, product, margin, canvasWidth, canvasHeight);
    fabricSaveHistory();
    autoSaveCanvasState(stateKey);
  });

  canvas.on('selection:created', () => {
    updateFabricStatus();
    updateLayerPanel();
    updateFabricImageDpiWarning(canvas, activePers, product);
  });

  canvas.on('selection:updated', () => {
    updateFabricStatus();
    updateLayerPanel();
    updateFabricImageDpiWarning(canvas, activePers, product);
  });

  canvas.on('selection:cleared', () => {
    removeCenterSnapGuides(canvas);

    const status = document.getElementById('status');

    if (status) {
      status.textContent = 'Selecteer een element om te bewerken. Klik en sleep om te verplaatsen.';
    }

    updateLayerPanel();
    updateFabricImageDpiWarning(canvas, activePers, product);
  });

  canvas.on('mouse:up', () => {
    removeCenterSnapGuides(canvas);
  });

  canvas.on('object:scaling', updateLayerPanel);
}

function bindFabricButtons(canvas, margin, canvasWidth, canvasHeight, stateKey, activePers, product) {
  document.getElementById('btn-logo')?.addEventListener('click', () => {
    document.getElementById('file-input')?.click();
  });

  document.getElementById('file-input')?.addEventListener('change', event => {
    const file = event.target.files?.[0];

    if (!file) {
      return;
    }

    const reader = new FileReader();

    reader.onload = readerEvent => {
      fabric.Image.fromURL(readerEvent.target.result, image => {
        const uploadMeta = createFabricImageUploadMeta(file, image);

        image.scaleToWidth(120);
        image.set({
          left: 140,
          top: 140,
          _uploadMeta: uploadMeta,
        });

        canvas.add(image);
        canvas.setActiveObject(image);
        canvas.renderAll();

        updateFabricImageDpiWarning(canvas, activePers, product, image);
        fabricSaveHistory();
        updateLayerPanel();
        autoSaveCanvasState(stateKey);
      });
    };

    reader.readAsDataURL(file);
    event.target.value = '';
  });

  document.getElementById('btn-text')?.addEventListener('click', () => {
    const text = new fabric.IText('Dubbelklik om tekst te bewerken', {
      left: 100,
      top: 160,
      fontSize: 20,
      fill: fabricActiveColor,
      fontFamily: document.getElementById('font-select')?.value || 'Georgia',
      editable: true,
    });

    canvas.add(text);
    canvas.setActiveObject(text);
    canvas.renderAll();

    syncFontSizeControls(text);
    fabricSaveHistory();
    updateLayerPanel();
    autoSaveCanvasState(stateKey);
  });

  document.getElementById('btn-delete')?.addEventListener('click', () => {
    const object = canvas.getActiveObject();

    if (object && !isGuideObject(object)) {
      canvas.remove(object);
      updateFabricImageDpiWarning(canvas, activePers, product);
      fabricSaveHistory();
      updateLayerPanel();
      autoSaveCanvasState(stateKey);
    }
  });

  document.getElementById('btn-front')?.addEventListener('click', () => {
    const object = canvas.getActiveObject();

    if (object && !isGuideObject(object)) {
      canvas.bringToFront(object);
      redrawGuides(canvas, activePers, product, margin, canvasWidth, canvasHeight);
      fabricSaveHistory();
      updateLayerPanel();
      autoSaveCanvasState(stateKey);
    }
  });

  document.getElementById('btn-back')?.addEventListener('click', () => {
    const object = canvas.getActiveObject();

    if (object && !isGuideObject(object)) {
      canvas.sendBackwards(object);
      redrawGuides(canvas, activePers, product, margin, canvasWidth, canvasHeight);
      fabricSaveHistory();
      updateLayerPanel();
      autoSaveCanvasState(stateKey);
    }
  });

  document.getElementById('btn-undo')?.addEventListener('click', () => {
    if (fabricHistory.length <= 1) {
      return;
    }

    fabricHistory.pop();

    canvas.loadFromJSON(fabricHistory[fabricHistory.length - 1], () => {
      restoreFabricImageUploadMeta(canvas);
      redrawGuides(canvas, activePers, product, margin, canvasWidth, canvasHeight);
      updateFabricImageDpiWarning(canvas, activePers, product);
      updateLayerPanel();
      autoSaveCanvasState(stateKey);
    });
  });

  document.getElementById('btn-clear')?.addEventListener('click', () => {
    canvas.clear();
    canvas.backgroundColor = fabricBackgroundColor;

    loadBackgroundImage(canvas, activePers, product, canvasWidth, canvasHeight);
    redrawGuides(canvas, activePers, product, margin, canvasWidth, canvasHeight);
    updateFabricImageDpiWarning(canvas, activePers, product);

    fabricSaveHistory();
    updateLayerPanel();
    clearDesignState(stateKey);
  });

  bindFontSelector(canvas, stateKey);
  bindFontSizeControl(canvas, stateKey);
  bindLayerDragAndDrop(canvas, stateKey);
}

function createFabricImageUploadMeta(file, image) {
  return {
    fileName: file?.name || 'Afbeelding',
    fileType: file?.type || getFileTypeFromName(file?.name || ''),
    widthPx: Number(image?.width || image?._element?.naturalWidth || 0),
    heightPx: Number(image?.height || image?._element?.naturalHeight || 0),
  };
}

function restoreFabricImageUploadMeta(canvas) {
  canvas.getObjects()
    .filter(object => object.type === 'image' && object._uploadMeta)
    .forEach(object => {
      object._uploadMeta = {
        fileName: object._uploadMeta.fileName || 'Afbeelding',
        fileType: object._uploadMeta.fileType || '',
        widthPx: Number(object._uploadMeta.widthPx || object.width || 0),
        heightPx: Number(object._uploadMeta.heightPx || object.height || 0),
      };
    });
}

function updateFabricImageDpiWarning(canvas, activePers, product, preferredObject = null) {
  const warningElement = document.getElementById('fabric-image-dpi-warning');

  if (!warningElement || !canvas) {
    return;
  }

  const imageObject = getSelectedFabricImageForDpiWarning(canvas, preferredObject);

  if (!imageObject) {
    warningElement.style.display = 'none';
    warningElement.textContent = '';
    return;
  }

  const warning = getFabricImageDpiWarningForCanvas(imageObject, canvas, activePers, product);

  if (!warning) {
    warningElement.style.display = 'none';
    warningElement.textContent = '';
    return;
  }

  const isError = warning.level === 'error';

  warningElement.style.display = 'block';
  warningElement.style.background = isError ? '#FCE8E3' : '#FFF3D8';
  warningElement.style.color = isError ? '#C0392B' : '#8A681E';
  warningElement.style.border = isError ? '1px solid #F3B7A8' : '1px solid #E6C46A';
  warningElement.textContent = warning.message;
}

function getSelectedFabricImageForDpiWarning(canvas, preferredObject = null) {
  if (preferredObject?.type === 'image' && preferredObject._uploadMeta && !isGuideObject(preferredObject)) {
    return preferredObject;
  }

  const activeObject = canvas.getActiveObject();

  if (!activeObject || isGuideObject(activeObject)) {
    return null;
  }

  if (activeObject.type === 'image' && activeObject._uploadMeta) {
    return activeObject;
  }

  if (activeObject.type === 'activeSelection' && typeof activeObject.getObjects === 'function') {
    return activeObject.getObjects()
      .find(object => object.type === 'image' && object._uploadMeta && !isGuideObject(object)) || null;
  }

  return null;
}

function getFabricImageDpiWarnings(canvas, activePers, product) {
  if (!canvas) {
    return [];
  }

  return canvas.getObjects()
    .filter(object => object.type === 'image' && !isGuideObject(object) && object._uploadMeta)
    .map(object => getFabricImageDpiWarningForCanvas(object, canvas, activePers, product))
    .filter(Boolean);
}

function getFabricImageDpiWarningForCanvas(object, canvas, activePers, product) {
  const canvasWidth = canvas.getWidth();
  const canvasHeight = canvas.getHeight();
  const widthMm = Number(activePers?.width_mm || product?.width_mm || 0);
  const heightMm = Number(activePers?.height_mm || product?.height_mm || 0);

  if (!canvasWidth || !canvasHeight || !widthMm || !heightMm) {
    return null;
  }

  return getFabricImageDpiWarning(object, canvasWidth, canvasHeight, widthMm, heightMm);
}

function getFabricImageDpiWarning(object, canvasWidth, canvasHeight, widthMm, heightMm) {
  const meta = object._uploadMeta || {};
  const sourceWidthPx = Number(meta.widthPx || 0);
  const sourceHeightPx = Number(meta.heightPx || 0);

  if (!sourceWidthPx || !sourceHeightPx) {
    return null;
  }

  const bounds = object.getBoundingRect(true, true);
  const placedWidthMm = (bounds.width / canvasWidth) * widthMm;
  const placedHeightMm = (bounds.height / canvasHeight) * heightMm;

  if (!placedWidthMm || !placedHeightMm) {
    return null;
  }

  const dpiX = Math.round((sourceWidthPx / placedWidthMm) * 25.4);
  const dpiY = Math.round((sourceHeightPx / placedHeightMm) * 25.4);
  const dpi = Math.min(dpiX, dpiY);
  const fileName = meta.fileName || 'afbeelding';

  if (dpi < IMAGE_DPI_MINIMUM) {
    return {
      type: 'fabric-image-resolution-low',
      level: 'error',
      fileName,
      dpi,
      message: `Waarschuwing: "${fileName}" lijkt te laag in resolutie voor drukwerk (${dpi} DPI). Gebruik een groter bestand of verklein de afbeelding in het ontwerp.`,
    };
  }

  if (dpi < IMAGE_DPI_RECOMMENDED) {
    return {
      type: 'fabric-image-resolution-warning',
      level: 'warning',
      fileName,
      dpi,
      message: `Let op: "${fileName}" is lager dan de aanbevolen 300 DPI (${dpi} DPI). Gebruik bij voorkeur een hogere resolutie of maak de afbeelding kleiner.`,
    };
  }

  return null;
}

function isOutsideMargin(object, margin, canvasWidth, canvasHeight) {
  const bounds = object.getBoundingRect(true, true);

  return bounds.left < margin ||
    bounds.top < margin ||
    bounds.left + bounds.width > canvasWidth - margin ||
    bounds.top + bounds.height > canvasHeight - margin;
}

function isObjectOverlappingBlockedZones(object, activePers, product, canvasWidth, canvasHeight) {
  if (!object || isGuideObject(object)) {
    return false;
  }

  const zones = Array.isArray(activePers?.blockedZones) ? activePers.blockedZones : [];

  if (!zones.length) {
    return false;
  }

  const bounds = object.getBoundingRect(true, true);

  return zones.some(zone => {
    if (zone.type === 'circle') {
      const circleData = getBlockedCircleCanvasData(zone, activePers, product, canvasWidth, canvasHeight);

      if (!circleData) {
        return false;
      }

      return isRectOverlappingCircle(bounds, circleData.cx, circleData.cy, circleData.safeRadius);
    }

    if (zone.type === 'rect') {
      const rectData = getBlockedRectCanvasData(zone, activePers, product, canvasWidth, canvasHeight);

      if (!rectData) {
        return false;
      }

      return isRectOverlappingRect(bounds, {
        left: rectData.safeLeft,
        top: rectData.safeTop,
        width: rectData.safeWidth,
        height: rectData.safeHeight,
      });
    }

    if (zone.type === 'line') {
      const lineData = getBlockedLineCanvasData(zone, activePers, product, canvasWidth, canvasHeight);

      if (!lineData) {
        return false;
      }

      return isRectNearLine(bounds, lineData.x1, lineData.y1, lineData.x2, lineData.y2, lineData.safeRadius);
    }

    return false;
  });
}

function isRectOverlappingCircle(rect, circleX, circleY, radius) {
  const closestX = clamp(circleX, rect.left, rect.left + rect.width);
  const closestY = clamp(circleY, rect.top, rect.top + rect.height);

  const distanceX = circleX - closestX;
  const distanceY = circleY - closestY;

  return (distanceX * distanceX + distanceY * distanceY) <= radius * radius;
}

function isRectOverlappingRect(rectA, rectB) {
  return rectA.left < rectB.left + rectB.width &&
    rectA.left + rectA.width > rectB.left &&
    rectA.top < rectB.top + rectB.height &&
    rectA.top + rectA.height > rectB.top;
}

function isRectNearLine(rect, x1, y1, x2, y2, radius) {
  const expandedRect = {
    left: rect.left - radius,
    top: rect.top - radius,
    right: rect.left + rect.width + radius,
    bottom: rect.top + rect.height + radius,
  };

  if (
    (x1 >= expandedRect.left && x1 <= expandedRect.right && y1 >= expandedRect.top && y1 <= expandedRect.bottom) ||
    (x2 >= expandedRect.left && x2 <= expandedRect.right && y2 >= expandedRect.top && y2 <= expandedRect.bottom)
  ) {
    return true;
  }

  const rectLines = [
    [expandedRect.left, expandedRect.top, expandedRect.right, expandedRect.top],
    [expandedRect.right, expandedRect.top, expandedRect.right, expandedRect.bottom],
    [expandedRect.right, expandedRect.bottom, expandedRect.left, expandedRect.bottom],
    [expandedRect.left, expandedRect.bottom, expandedRect.left, expandedRect.top],
  ];

  return rectLines.some(([rx1, ry1, rx2, ry2]) =>
    doLineSegmentsIntersect(x1, y1, x2, y2, rx1, ry1, rx2, ry2)
  );
}

function doLineSegmentsIntersect(x1, y1, x2, y2, x3, y3, x4, y4) {
  const direction = (ax, ay, bx, by, cx, cy) => {
    return (cx - ax) * (by - ay) - (cy - ay) * (bx - ax);
  };

  const d1 = direction(x3, y3, x4, y4, x1, y1);
  const d2 = direction(x3, y3, x4, y4, x2, y2);
  const d3 = direction(x1, y1, x2, y2, x3, y3);
  const d4 = direction(x1, y1, x2, y2, x4, y4);

  return ((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) &&
    ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0));
}

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function collectCanvasPrepressWarnings(canvas, activePers, product) {
  if (!canvas) {
    return [];
  }

  const state = window._currentDesignGuideState || {};
  const canvasWidth = state.canvasWidth || canvas.getWidth();
  const canvasHeight = state.canvasHeight || canvas.getHeight();
  const margin = state.margin !== undefined
    ? state.margin
    : getFallbackCanvasMargin(activePers, product, canvasWidth);
  const warnings = [];
  const editableObjects = canvas.getObjects().filter(object => !isGuideObject(object));
  const outsideMarginCount = editableObjects.filter(object => isOutsideMargin(object, margin, canvasWidth, canvasHeight)).length;
  const blockedZoneCount = editableObjects.filter(object => isObjectOverlappingBlockedZones(object, activePers, product, canvasWidth, canvasHeight)).length;
  const imageDpiWarnings = getFabricImageDpiWarnings(canvas, activePers, product);

  if (outsideMarginCount > 0) {
    warnings.push({
      type: 'safe-margin',
      level: 'warning',
      message: outsideMarginCount === 1
        ? 'Een element staat buiten de veilige marge.'
        : `${outsideMarginCount} elementen staan buiten de veilige marge.`,
    });
  }

  if (blockedZoneCount > 0) {
    warnings.push({
      type: 'blocked-zone',
      level: 'warning',
      message: blockedZoneCount === 1
        ? 'Een element raakt een rillijn of no-print zone.'
        : `${blockedZoneCount} elementen raken een rillijn of no-print zone.`,
    });
  }

  imageDpiWarnings.forEach(warning => {
    warnings.push({
      type: warning.type,
      level: warning.level === 'error' ? 'warning' : warning.level,
      message: warning.message,
      fileName: warning.fileName,
      dpi: warning.dpi,
    });
  });

  return warnings;
}

function getFallbackCanvasMargin(activePers, product, canvasWidth) {
  const sourceMarginPx = Number(activePers?.margin_px || product?.margin_px || 20);
  const sourceWidthPx = Number(activePers?.width_px || product?.width_px || 1181);

  if (!sourceWidthPx) {
    return sourceMarginPx;
  }

  return sourceMarginPx * (canvasWidth / sourceWidthPx);
}

function updateFabricStatus() {
  const object = fabricCanvas?.getActiveObject();
  const status = document.getElementById('status');

  if (!object || !status) {
    return;
  }

  status.textContent = `${object.type === 'i-text' ? 'Tekst' : 'Afbeelding'} geselecteerd. Sleep, schaal of roteer.`;
}

function updateLayerPanel() {
  const panel = document.getElementById('layer-list');

  if (!panel || !fabricCanvas) {
    return;
  }

  panel.innerHTML = '';

  fabricCanvas.getObjects()
    .filter(object => !isGuideObject(object))
    .reverse()
    .forEach((object, index) => {
      const item = document.createElement('div');
      item.className = 'layer-item';
      item.draggable = true;
      item.dataset.objectId = getFabricObjectId(object);
      item.textContent = object.type === 'i-text'
        ? `${index + 1}. Tekst: "${object.text}"`
        : `${index + 1}. Afbeelding`;

      if (fabricCanvas.getActiveObject() === object) {
        item.classList.add('active');
      }

      item.addEventListener('click', () => {
        fabricCanvas.setActiveObject(object);
        fabricCanvas.renderAll();

        updateFabricImageDpiWarning(
          fabricCanvas,
          window._currentDesignGuideState?.activePers,
          window._currentDesignGuideState?.product,
          object
        );
      });

      panel.appendChild(item);
    });
}

function bindLayerDragAndDrop(canvas, stateKey) {
  const panel = document.getElementById('layer-list');

  if (!panel) {
    return;
  }

  panel.addEventListener('dragstart', event => {
    const item = event.target.closest('.layer-item');

    if (!item) {
      return;
    }

    event.dataTransfer.setData('text/plain', item.dataset.objectId);
    item.classList.add('dragging');
  });

  panel.addEventListener('dragend', event => {
    event.target.closest('.layer-item')?.classList.remove('dragging');
  });

  panel.addEventListener('dragover', event => {
    event.preventDefault();
  });

  panel.addEventListener('drop', event => {
    event.preventDefault();

    const draggedId = event.dataTransfer.getData('text/plain');
    const targetItem = event.target.closest('.layer-item');

    if (!draggedId || !targetItem) {
      return;
    }

    const targetId = targetItem.dataset.objectId;

    if (draggedId === targetId) {
      return;
    }

    reorderCanvasObjectsFromLayerDrop(canvas, draggedId, targetId);
    fabricSaveHistory();
    autoSaveCanvasState(stateKey);
    updateLayerPanel();
  });
}

function reorderCanvasObjectsFromLayerDrop(canvas, draggedId, targetId) {
  const editableObjects = canvas.getObjects().filter(object => !isGuideObject(object));
  const draggedObject = editableObjects.find(object => getFabricObjectId(object) === draggedId);
  const targetObject = editableObjects.find(object => getFabricObjectId(object) === targetId);

  if (!draggedObject || !targetObject) {
    return;
  }

  const fromIndex = editableObjects.indexOf(draggedObject);
  const toIndex = editableObjects.indexOf(targetObject);

  if (fromIndex === -1 || toIndex === -1) {
    return;
  }

  editableObjects.splice(fromIndex, 1);
  editableObjects.splice(toIndex, 0, draggedObject);

  const activeObject = canvas.getActiveObject();
  const backgroundColor = canvas.backgroundColor;
  const backgroundImage = canvas.backgroundImage || null;

  editableObjects.forEach((object, index) => {
    if (typeof canvas.moveTo === 'function') {
      canvas.moveTo(object, index);
      return;
    }

    if (typeof object.moveTo === 'function') {
      object.moveTo(index);
    }
  });

  canvas.backgroundColor = backgroundColor;
  canvas.backgroundImage = backgroundImage;

  bringGuidesToFront(canvas);

  if (activeObject && !isGuideObject(activeObject)) {
    canvas.setActiveObject(activeObject);
  }

  canvas.renderAll();
}

function getFabricObjectId(object) {
  if (!object._layerId) {
    object._layerId = `layer-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  }

  return object._layerId;
}

function applyToSelected(property, value) {
  const object = fabricCanvas?.getActiveObject();

  if (object && object.type === 'i-text' && !isGuideObject(object)) {
    object.set(property, value);
    fabricCanvas.renderAll();
    fabricSaveHistory();
    updateLayerPanel();
    autoSaveCanvasState(window._currentDesignStateKey);
  }
}

function fabricSaveHistory() {
  if (!fabricCanvas) {
    return;
  }

  const guideObjects = getGuideObjects(fabricCanvas);

  guideObjects.forEach(object => {
    object.visible = false;
  });

  const json = JSON.stringify(fabricCanvas.toJSON(['_layerId', '_uploadMeta']));

  guideObjects.forEach(object => {
    object.visible = true;
  });

  fabricHistory.push(json);

  if (fabricHistory.length > 20) {
    fabricHistory.shift();
  }

  fabricCanvas.renderAll();
}

function snapshotCanvas(canvas, product, activePers) {
  const guideObjects = getGuideObjects(canvas);

  guideObjects.forEach(object => {
    object.visible = false;
  });

  canvas.discardActiveObject();
  canvas.renderAll();

  const printWidthPx = activePers?.width_px || product.width_px || 1181;
  const displayWidthPx = canvas.getWidth();
  const multiplier = printWidthPx / displayWidthPx;

  const dataURL = canvas.toDataURL({
    format: 'png',
    multiplier,
    enableRetinaScaling: false,
  });

  guideObjects.forEach(object => {
    object.visible = true;
  });

  canvas.renderAll();

  const json = JSON.stringify(canvas.toJSON(['_layerId', '_uploadMeta']));
  const backgroundColor = canvas.backgroundColor || fabricBackgroundColor;
  const finishWidthMm = activePers?.width_mm || product.width_mm || 100;
  const finishHeightMm = activePers?.height_mm || product.height_mm || 70;

  const pdfDataURL = generatePrintPDF(
    dataURL,
    finishWidthMm,
    finishHeightMm
  );

  const rillinesPdfDataURL = generatePrintPDFWithRillines(
    dataURL,
    finishWidthMm,
    finishHeightMm,
    activePers,
    product
  );

  return {
    dataURL,
    json,
    backgroundColor,
    pdfDataURL,
    rillinesPdfDataURL,
  };
}

function generatePrintPDF(pngDataURL, widthMm, heightMm) {
  if (!window.jspdf) {
    console.warn('jsPDF niet geladen');
    return null;
  }

  const { jsPDF } = window.jspdf;
  const pdfGeometry = getPrintPdfGeometry(widthMm, heightMm);

  const pdf = new jsPDF({
    orientation: pdfGeometry.pageW > pdfGeometry.pageH ? 'landscape' : 'portrait',
    unit: 'mm',
    format: [pdfGeometry.pageW, pdfGeometry.pageH],
    compress: true,
  });

  pdf.addImage(pngDataURL, 'PNG', 0, 0, pdfGeometry.pageW, pdfGeometry.pageH, '', 'FAST');
  drawCropMarks(pdf, pdfGeometry);

  return pdf.output('datauristring');
}

function generatePrintPDFWithRillines(pngDataURL, widthMm, heightMm, activePers, product) {
  if (!window.jspdf) {
    console.warn('jsPDF niet geladen');
    return null;
  }

  const { jsPDF } = window.jspdf;
  const pdfGeometry = getPrintPdfGeometry(widthMm, heightMm);

  const pdf = new jsPDF({
    orientation: pdfGeometry.pageW > pdfGeometry.pageH ? 'landscape' : 'portrait',
    unit: 'mm',
    format: [pdfGeometry.pageW, pdfGeometry.pageH],
    compress: true,
  });

  pdf.addImage(pngDataURL, 'PNG', 0, 0, pdfGeometry.pageW, pdfGeometry.pageH, '', 'FAST');
  drawCropMarks(pdf, pdfGeometry);
  drawRillinesOnPdf(pdf, pdfGeometry, activePers, product);

  return pdf.output('datauristring');
}

function getPrintPdfGeometry(widthMm, heightMm) {
  const bleedMm = 3;
  const markMm = 5;
  const gapMm = 2.117;
  const pageW = Number(widthMm || 100) + bleedMm * 2;
  const pageH = Number(heightMm || 70) + bleedMm * 2;

  return {
    bleedMm,
    markMm,
    gapMm,
    pageW,
    pageH,
    trimX1: bleedMm,
    trimY1: bleedMm,
    trimX2: bleedMm + Number(widthMm || 100),
    trimY2: bleedMm + Number(heightMm || 70),
  };
}

function drawCropMarks(pdf, geometry) {
  pdf.setDrawColor(0, 0, 0);
  pdf.setLineWidth(0.088);

  pdf.line(geometry.trimX1 - geometry.gapMm - geometry.markMm, geometry.trimY1, geometry.trimX1 - geometry.gapMm, geometry.trimY1);
  pdf.line(geometry.trimX1, geometry.trimY1 - geometry.gapMm - geometry.markMm, geometry.trimX1, geometry.trimY1 - geometry.gapMm);

  pdf.line(geometry.trimX2 + geometry.gapMm, geometry.trimY1, geometry.trimX2 + geometry.gapMm + geometry.markMm, geometry.trimY1);
  pdf.line(geometry.trimX2, geometry.trimY1 - geometry.gapMm - geometry.markMm, geometry.trimX2, geometry.trimY1 - geometry.gapMm);

  pdf.line(geometry.trimX1 - geometry.gapMm - geometry.markMm, geometry.trimY2, geometry.trimX1 - geometry.gapMm, geometry.trimY2);
  pdf.line(geometry.trimX1, geometry.trimY2 + geometry.gapMm, geometry.trimX1, geometry.trimY2 + geometry.gapMm + geometry.markMm);

  pdf.line(geometry.trimX2 + geometry.gapMm, geometry.trimY2, geometry.trimX2 + geometry.gapMm + geometry.markMm, geometry.trimY2);
  pdf.line(geometry.trimX2, geometry.trimY2 + geometry.gapMm, geometry.trimX2, geometry.trimY2 + geometry.gapMm + geometry.markMm);
}

function drawRillinesOnPdf(pdf, geometry, activePers, product) {
  const zones = Array.isArray(activePers?.blockedZones) ? activePers.blockedZones : [];
  const sourceWidthMm = Number(activePers?.width_mm || product?.width_mm || 0);
  const sourceHeightMm = Number(activePers?.height_mm || product?.height_mm || 0);

  if (!zones.length || !sourceWidthMm || !sourceHeightMm) {
    return;
  }

  pdf.setDrawColor(0, 255, 255);
  pdf.setLineWidth(0.25);

  zones
    .filter(zone => zone.type === 'line')
    .forEach(zone => {
      let x1Mm = Number(zone.x1_mm || 0);
      let y1Mm = Number(zone.y1_mm || 0);
      let x2Mm = Number(zone.x2_mm || 0);
      let y2Mm = Number(zone.y2_mm || 0);

      const deltaXmm = Math.abs(x2Mm - x1Mm);
      const deltaYmm = Math.abs(y2Mm - y1Mm);

      if (deltaYmm <= 0.01) {
        const centerYmm = (y1Mm + y2Mm) / 2;
        x1Mm = 0;
        x2Mm = sourceWidthMm;
        y1Mm = centerYmm;
        y2Mm = centerYmm;
      } else if (deltaXmm <= 0.01) {
        const centerXmm = (x1Mm + x2Mm) / 2;
        x1Mm = centerXmm;
        x2Mm = centerXmm;
        y1Mm = 0;
        y2Mm = sourceHeightMm;
      }

      const x1 = geometry.trimX1 + (x1Mm / sourceWidthMm) * (geometry.trimX2 - geometry.trimX1);
      const y1 = geometry.trimY1 + (y1Mm / sourceHeightMm) * (geometry.trimY2 - geometry.trimY1);
      const x2 = geometry.trimX1 + (x2Mm / sourceWidthMm) * (geometry.trimX2 - geometry.trimX1);
      const y2 = geometry.trimY1 + (y2Mm / sourceHeightMm) * (geometry.trimY2 - geometry.trimY1);

      if (typeof pdf.setLineDashPattern === 'function') {
        pdf.setLineDashPattern([1, 0.75], 0);
      }

      pdf.line(x1, y1, x2, y2);

      if (typeof pdf.setLineDashPattern === 'function') {
        pdf.setLineDashPattern([], 0);
      }
    });
}

function autoSaveCanvasState(stateKey) {
  if (!fabricCanvas || !stateKey) {
    return;
  }

  const guideObjects = getGuideObjects(fabricCanvas);

  guideObjects.forEach(object => {
    object.visible = false;
  });

  const json = JSON.stringify(fabricCanvas.toJSON(['_layerId', '_uploadMeta']));

  guideObjects.forEach(object => {
    object.visible = true;
  });

  persistDesignState(stateKey, {
    fabricJSON: json,
    backgroundColor: fabricCanvas.backgroundColor || fabricBackgroundColor,
  });

  fabricCanvas.renderAll();
}

function getGuideObjects(canvas) {
  return canvas.getObjects().filter(object => isGuideObject(object));
}

function persistDesignState(stateKey, data) {
  if (!stateKey) {
    return;
  }

  try {
    const current = JSON.parse(localStorage.getItem(stateKey) || '{}');

    localStorage.setItem(stateKey, JSON.stringify({
      ...current,
      ...data,
      savedAt: Date.now(),
    }));
  } catch (error) {
    console.warn('Design state opslaan mislukt', error);
  }
}

function loadDesignState(stateKey) {
  try {
    const raw = localStorage.getItem(stateKey);

    if (!raw) {
      return null;
    }

    const state = JSON.parse(raw);

    if (Date.now() - (state.savedAt || 0) > 86400000) {
      localStorage.removeItem(stateKey);
      return null;
    }

    return state;
  } catch {
    return null;
  }
}

function clearDesignState(stateKey) {
  if (!stateKey) {
    return;
  }

  localStorage.removeItem(stateKey);
}

async function handleUpload(file, stateKey, activePers, product) {
  const uploadCheck = await buildUploadCheck(file, activePers, product);
  const reader = new FileReader();

  reader.onload = event => {
    uploadedDataURL = event.target.result;
    uploadedFileName = file.name;
    uploadedCheck = uploadCheck;

    const generatedUploadPdfs = buildUploadPdfData(uploadedDataURL, activePers, product);

    uploadedPdfDataURL = generatedUploadPdfs.pdfDataURL;
    uploadedRillinesPdfDataURL = generatedUploadPdfs.rillinesPdfDataURL;

    const data = {
      dataURL: uploadedDataURL,
      pdfDataURL: uploadedPdfDataURL,
      rillinesPdfDataURL: uploadedRillinesPdfDataURL,
      fileName: uploadedFileName,
      tab: 'upload',
      source: 'upload',
      uploadCheck: uploadedCheck,
      prepressWarnings: getUploadPrepressWarnings(uploadedCheck),
    };

    Session.setDesign(data);
    persistDesignState(stateKey, data);
    renderDesignPage();
  };

  reader.readAsDataURL(file);
}

function buildUploadPdfData(dataURL, activePers, product) {
  const finishWidthMm = activePers?.width_mm || product?.width_mm || 100;
  const finishHeightMm = activePers?.height_mm || product?.height_mm || 70;

  if (dataURL?.startsWith('data:application/pdf')) {
    return {
      pdfDataURL: dataURL,
      rillinesPdfDataURL: '',
    };
  }

  if (!dataURL?.startsWith('data:image')) {
    return {
      pdfDataURL: '',
      rillinesPdfDataURL: '',
    };
  }

  return {
    pdfDataURL: generatePrintPDF(dataURL, finishWidthMm, finishHeightMm) || '',
    rillinesPdfDataURL: generatePrintPDFWithRillines(dataURL, finishWidthMm, finishHeightMm, activePers, product) || '',
  };
}

function buildUploadCheck(file, activePers, product) {
  const fileName = file?.name || '';
  const fileType = file?.type || getFileTypeFromName(fileName);
  const extension = getFileExtension(fileName);
  const printSpec = getUploadPrintSpec(activePers, product);
  const requiredWidthPx = printSpec.requiredWidthPx;
  const requiredHeightPx = printSpec.requiredHeightPx;

  if (!file) {
    return Promise.resolve(null);
  }

  if (['pdf', 'ai', 'eps'].includes(extension)) {
    return Promise.resolve({
      fileName,
      fileType,
      widthPx: null,
      heightPx: null,
      requiredWidthPx,
      requiredHeightPx,
      estimatedDpiX: null,
      estimatedDpiY: null,
      status: 'manual-check',
      message: 'Dit bestand wordt technisch gecontroleerd in Adobe.',
    });
  }

  if (!fileType.startsWith('image/') && !['png', 'jpg', 'jpeg'].includes(extension)) {
    return Promise.resolve({
      fileName,
      fileType,
      widthPx: null,
      heightPx: null,
      requiredWidthPx,
      requiredHeightPx,
      estimatedDpiX: null,
      estimatedDpiY: null,
      status: 'warning',
      message: 'Dit bestandstype kan niet automatisch op resolutie worden gecontroleerd.',
    });
  }

  return getUploadedImageDimensions(file)
    .then(dimensions => {
      const estimatedDpiX = printSpec.exportWidthMm
        ? Math.round((dimensions.widthPx / printSpec.exportWidthMm) * 25.4)
        : null;
      const estimatedDpiY = printSpec.exportHeightMm
        ? Math.round((dimensions.heightPx / printSpec.exportHeightMm) * 25.4)
        : null;
      const minDpi = Math.min(estimatedDpiX || 0, estimatedDpiY || 0);

      let status = 'good';
      let message = 'De afbeelding heeft voldoende resolutie voor drukwerk op 300 DPI.';

      if (minDpi < 150) {
        status = 'error';
        message = `De afbeelding lijkt te laag in resolutie. Advies: minimaal ${requiredWidthPx} × ${requiredHeightPx}px voor 300 DPI.`;
      } else if (minDpi < 300) {
        status = 'warning';
        message = `De afbeelding is bruikbaar, maar lager dan de aanbevolen 300 DPI. Advies: ${requiredWidthPx} × ${requiredHeightPx}px.`;
      }

      return {
        fileName,
        fileType,
        widthPx: dimensions.widthPx,
        heightPx: dimensions.heightPx,
        requiredWidthPx,
        requiredHeightPx,
        estimatedDpiX,
        estimatedDpiY,
        status,
        message,
      };
    })
    .catch(() => ({
      fileName,
      fileType,
      widthPx: null,
      heightPx: null,
      requiredWidthPx,
      requiredHeightPx,
      estimatedDpiX: null,
      estimatedDpiY: null,
      status: 'warning',
      message: 'De resolutie van dit bestand kon niet automatisch worden gecontroleerd.',
    }));
}

function getUploadPrintSpec(activePers, product) {
  if (window.PrintSpecs?.normalizePrintSpec) {
    const spec = PrintSpecs.normalizePrintSpec(activePers || {}, product || {});

    return {
      exportWidthMm: spec.exportWidthMm,
      exportHeightMm: spec.exportHeightMm,
      requiredWidthPx: spec.requiredImageWidthPx300 || spec.exportWidthPx,
      requiredHeightPx: spec.requiredImageHeightPx300 || spec.exportHeightPx,
    };
  }

  const widthMm = Number(activePers?.width_mm || product?.width_mm || 100);
  const heightMm = Number(activePers?.height_mm || product?.height_mm || 70);

  return {
    exportWidthMm: widthMm,
    exportHeightMm: heightMm,
    requiredWidthPx: Math.round((widthMm / 25.4) * 300),
    requiredHeightPx: Math.round((heightMm / 25.4) * 300),
  };
}

function getUploadedImageDimensions(file) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    const url = URL.createObjectURL(file);

    image.onload = () => {
      URL.revokeObjectURL(url);

      resolve({
        widthPx: image.naturalWidth,
        heightPx: image.naturalHeight,
      });
    };

    image.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Afbeelding kon niet worden gelezen.'));
    };

    image.src = url;
  });
}

function getUploadPrepressWarnings(uploadCheck) {
  if (!uploadCheck) {
    return [];
  }

  if (uploadCheck.status === 'manual-check') {
    return [{
      type: 'upload-vector-check',
      level: 'info',
      message: 'Dit bestand moet technisch worden gecontroleerd in Adobe.',
    }];
  }

  if (uploadCheck.status === 'warning') {
    return [{
      type: 'upload-resolution-warning',
      level: 'warning',
      message: uploadCheck.message || 'De upload heeft mogelijk een te lage resolutie.',
    }];
  }

  if (uploadCheck.status === 'error') {
    return [{
      type: 'upload-resolution-error',
      level: 'warning',
      message: uploadCheck.message || 'De upload heeft waarschijnlijk een te lage resolutie.',
    }];
  }

  return [];
}

function getUploadCheckBackground(status) {
  if (status === 'good') {
    return '#EDF2ED';
  }

  if (status === 'error') {
    return '#FCE8E3';
  }

  return '#FFF3D8';
}

function getUploadCheckTextColor(status) {
  if (status === 'good') {
    return '#3E5A3E';
  }

  if (status === 'error') {
    return '#C0392B';
  }

  return '#8A681E';
}

function getFileExtension(fileName) {
  return String(fileName || '').split('.').pop().toLowerCase();
}

function getFileTypeFromName(fileName) {
  const extension = getFileExtension(fileName);

  const map = {
    pdf: 'application/pdf',
    ai: 'application/postscript',
    eps: 'application/postscript',
    png: 'image/png',
    jpg: 'image/jpeg',
    jpeg: 'image/jpeg',
  };

  return map[extension] || '';
}

function clearUpload() {
  uploadedDataURL = null;
  uploadedFileName = null;
  uploadedCheck = null;
  uploadedPdfDataURL = null;
  uploadedRillinesPdfDataURL = null;

  Session.setDesign({
    dataURL: null,
    pdfDataURL: null,
    rillinesPdfDataURL: null,
    fileName: null,
    tab: 'upload',
    source: null,
    uploadCheck: null,
    prepressWarnings: [],
  });

  renderDesignPage();
}

function getPersonalisationImageSrc(persType, product) {
  return persType?.previewImageFile?.dataURL ||
    persType?.previewImage ||
    product?.imageProductFile?.dataURL ||
    product?.imageProduct ||
    '';
}

function escHtml(value) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

window.clearUpload = clearUpload;